#if (defined(__GNUC__) || defined(__clang__))
#pragma GCC diagnostic pop

#elif defined(_MSC_VER)
#pragma warning(pop)
#endif
